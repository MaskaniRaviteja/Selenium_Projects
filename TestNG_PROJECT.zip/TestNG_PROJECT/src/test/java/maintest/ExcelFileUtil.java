package maintest;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelFileUtil 

{
	
	Workbook wb;
	public ExcelFileUtil(String excelpath) throws Throwable
	{
		FileInputStream fi=new FileInputStream(excelpath);
		wb=WorkbookFactory.create(fi);
	}
	 public int rowCount(String sheetname)
	 {
		 return wb.getSheet(sheetname).getLastRowNum();
	 }
	
	 public int colCount(String sheetname)
	 {
		 return wb.getSheet(sheetname).getRow(0).getLastCellNum();
	 }
	 
	 public String getCellData(String sheetname, int row, int column)
	 {
		 String data="";
		 if(wb.getSheet(sheetname).getRow(row).getCell(column).getCellType()==CellType.NUMERIC)
		 {
			 long celldata=(long) wb.getSheet(sheetname).getRow(row).getCell(column).getNumericCellValue();
			 data=String.valueOf(celldata);
		 }
		 else
		 {
			 data=wb.getSheet(sheetname).getRow(row).getCell(column).getStringCellValue();
		 }
		 return data;
	 }
	 
	 public int getCellData1(String sheetname, int row, int column)
	 {	 
		  Cell c1= wb.getSheet(sheetname).getRow(row).getCell(column);
		int datacell= (int) c1.getNumericCellValue();
		
		 return datacell;
		 
	 }
}
