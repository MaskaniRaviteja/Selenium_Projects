package maintest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DriverClass {
	String FILE_PATH = "C:\\Users\\ptpl-395\\eclipse-workspace\\TestNG_PROJECT\\TestData\\outputdata.xlsx";

	WebDriver driver;

	@BeforeTest
	public void setup() {
		String browserName = "Chrome";
		if (browserName.equals("Chrome")) {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			driver = new ChromeDriver(options);
		} else if (browserName.equals("Firefox")) {
			System.setProperty("webdriver.gecko.driver", "path/to/geckodriver");
			driver = new FirefoxDriver();
		} else {
			System.out.println("Please provide a valid browser name");
		}
	}

	@AfterTest
	public void tearDown() {
		driver.close();
		driver.quit();
	}

	@Test(priority = 1)
	public void verifyLoginWithInValidCredentials() throws Throwable {

		driver.get("https://www.instagram.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));

		ExcelFileUtil xl = new ExcelFileUtil(FILE_PATH);
		int rowCount = xl.rowCount("InvalidData");

		for (int i = 1; i <= rowCount; i++) {
			driver.navigate().refresh();
			driver.findElement(By.xpath("//input[@name='username']")).sendKeys(xl.getCellData("InvalidData", i, 0));
			driver.findElement(By.xpath("//input[@name='password']")).sendKeys(xl.getCellData("InvalidData", i, 1));
			driver.findElement(By.xpath("//button[@type='submit']")).click();
			String error_msg = driver.findElement(By.id("slfErrorAlert")).getText();

			Assert.assertTrue(driver.findElement(By.id("slfErrorAlert")).isDisplayed(), "Login failed for username: "
					+ xl.getCellData("InvalidData", i, 0) + ", password: " + xl.getCellData("InvalidData", i, 1));
			System.out.println(error_msg + ", Login failed for username: " + xl.getCellData("InvalidData", i, 0)
					+ ", password: " + xl.getCellData("InvalidData", i, 1));
		}
	}

	@Test(priority = 2)
	public void verifyLoginWithValidCredentials() throws Throwable {

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));

		ExcelFileUtil xl = new ExcelFileUtil(FILE_PATH);
		int rowCount = xl.rowCount("validData");
		for (int i = 1; i <= rowCount; i++) {
			driver.navigate().refresh();
			driver.findElement(By.xpath("//input[@name='username']")).sendKeys(xl.getCellData("validData", i, 0));
			driver.findElement(By.xpath("//input[@name='password']")).sendKeys(xl.getCellData("validData", i, 1));
			driver.findElement(By.xpath("//button[@type='submit']")).click();
//
//			Assert.assertTrue(driver.findElement(By.id("slfErrorAlert")).isDisplayed(), "Login is succesful for user: "
//					+ xl.getCellData("InvalidData", i, 0) + ", password: " + xl.getCellData("InvalidData", i, 1));

		}
	}
}
